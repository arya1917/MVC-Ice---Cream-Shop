using System.Collections.Generic;

namespace IceCreamShop.Models
{
    public class IceCreamOrder
    {
        public List<IceCreamItem> Items { get; set; } = new List<IceCreamItem>();
        public double TotalAmount { get; set; }
        public double Gst { get; set; }
    }

    public class IceCreamItem
    {
        public string Flavor { get; set; }
        public int Quantity { get; set; }
        public double Price { get; set; }
        public double Amount => Price * Quantity;
    }
}
