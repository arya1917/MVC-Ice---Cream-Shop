using Microsoft.AspNetCore.Mvc;
using IceCreamShop.Models;
using System.Collections.Generic;

namespace IceCreamShop.Controllers
{
    public class HomeController : Controller
    {
        private readonly Dictionary<string, double> _menu = new()
        {
            { "Vanila", 100 },
            { "Mango", 100 },
            { "Strawberry", 150 },
            { "Chocolate", 200 },
            { "Blackberry", 300 }
        };

        public IActionResult Index()
        {
            return View(new IceCreamOrder());
        }

        [HttpPost]
        public IActionResult Order(IceCreamOrder order)
        {
            if (order.Items != null && order.Items.Count > 0)
            {
                foreach (var item in order.Items)
                {
                    if (item.Quantity > 0 && _menu.ContainsKey(item.Flavor))
                    {
                        item.Price = _menu[item.Flavor];
                        order.TotalAmount += item.Price * item.Quantity;
                    }
                }
                order.Gst = order.TotalAmount * 0.08; // 8% GST
                order.TotalAmount += order.Gst;
                return View("Billing", order);
            }
            return View("Index", order); // Return to Index on invalid input
        }
    }
}
