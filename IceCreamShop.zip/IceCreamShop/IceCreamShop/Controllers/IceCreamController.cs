using Microsoft.AspNetCore.Mvc;
using System;

namespace IceCreamShop.Controllers
{
    public class IceCreamController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Menu()
        {
            return View();
        }

        public IActionResult Order()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Order(string flavor, int quantity)
        {
            ViewBag.Flavor = flavor;
            ViewBag.Quantity = quantity;
            ViewBag.Amount = CalculateAmount(flavor, quantity);
            return View("OrderSummary");
        }

        public IActionResult Billing(double amount)
        {
            double gst = 0.08 * amount;
            double totalAmount = amount + gst;
            ViewBag.Amount = amount;
            ViewBag.TotalAmount = totalAmount;
            ViewBag.GST = gst;
            return View();
        }

        private double CalculateAmount(string flavor, int quantity)
        {
            double price = 0.0;
            switch (flavor.ToLower())
            {
                case "vanila":
                    price = 100;
                    break;
                case "mango":
                    price = 100;
                    break;
                case "straw":
                    price = 150;
                    break;
                case "chocolate":
                    price = 200;
                    break;
                case "blackberry":
                    price = 300;
                    break;
            }
            return price * quantity;
        }
    }
}
